


// TESTED ON IPHONE: 11 , 11 Pro Max

import UIKit
import Foundation
import AVFoundation


class ViewController: UIViewController {
    
    var originalPosition: CGPoint!
    
    
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button4: UIButton!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var image1: UIImageView!
    
    var b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0
    
    
    class MusicPlayer {
        static let shared = MusicPlayer()
        var audioPlayer: AVAudioPlayer?

        func startBackgroundMusic() {
            if let bundle = Bundle.main.path(forResource: "2020-06-05_-_Duck_Duck_Goose_-_www.FesliyanStudios.com_David_Renda", ofType: "mp3") {
                let backgroundMusic = NSURL(fileURLWithPath: bundle)
                do {
                    audioPlayer = try AVAudioPlayer(contentsOf:backgroundMusic as URL)
                    guard let audioPlayer = audioPlayer else { return }
                    audioPlayer.numberOfLoops = -1
                    audioPlayer.prepareToPlay()
                    audioPlayer.play()
                } catch {
                    print(error)
                }
            }
            MusicPlayer.shared.startBackgroundMusic()
        }
        
    }
    
    
    @IBAction func buttonPressed () {
        originalPosition = button.center
        //print(button.center)
    }
    @IBAction func buttonPressed1 () {
        originalPosition = button1.center
        //print(button1.center)
    }
    @IBAction func buttonPressed2 () {
        originalPosition = button2.center
        //print(button2.center)
    }
    @IBAction func buttonPressed3 () {
        originalPosition = button3.center
        //print(button3.center)
    }
    @IBAction func buttonPressed4 () {
        originalPosition = button4.center
        //print(button4.center)
    }
    
    @IBAction func buttonMoved(sender: UIButton, forEvent event: UIEvent) {
        let touches = event.allTouches
        
        for touch in touches!
        {
            button.center = touch.location(in:  self.viewIfLoaded)
             //print(button.center)
        }
    }
    @IBAction func buttonMoved1(sender: UIButton, forEvent event: UIEvent) {
        let touches = event.allTouches
        
        for touch in touches!
        {
            button1.center = touch.location(in:  self.viewIfLoaded)
            //print(button1.center)
        }
    }
    @IBAction func buttonMoved2(sender: UIButton, forEvent event: UIEvent) {
        let touches = event.allTouches
        
        for touch in touches!
        {
            button2.center = touch.location(in:  self.viewIfLoaded)
            //print(button2.center)
        }
    }
    @IBAction func buttonMoved3(sender: UIButton, forEvent event: UIEvent) {
        let touches = event.allTouches
        
        for touch in touches!
        {
            button3.center = touch.location(in:  self.viewIfLoaded)
            //print(button3.center)
        }
    }
    @IBAction func buttonMoved4(sender: UIButton, forEvent event: UIEvent) {
        let touches = event.allTouches
        
        for touch in touches!
        {
            button4.center = touch.location(in:  self.viewIfLoaded)
            //print(button4.center)
            
        }
    
    }
    @IBAction func buttonReleased() {
        if(distanceBetweenPoint(point1: button.center, point2 : CGPoint(x:292 , y:492)) < 40){
            button.center = CGPoint(x:292 , y:492)
            b0=1
            //print("button0=",b0)
        }
        else{
            let startingPoint = button.center
            let endpoint = CGPoint(x: 332 , y:275 )
            let animationDuration = 2.0
            
            let positionAnimation = constructPositionAnimation(startingPoint: startingPoint, endpoint: endpoint, animationDuration: animationDuration)
            button.layer.add(positionAnimation    , forKey: "position")
            button.layer.position = endpoint
            //button.center = originalPosition
            //print("button0=",b0)
            b0=0
        }
            if(b0 == 1 && b1 == 1 && b2 == 1 && b3 == 1 && b4 == 1 ) {
        
                func somehandler(alert: UIAlertAction){
                    button4.center = CGPoint(x: 123.66 , y:294 )
                    button3.center = CGPoint(x: 329 , y:374 )
                    button2.center = CGPoint(x: 229.5 , y:298.5 )
                    button1.center = CGPoint(x: 123.5 , y:374 )
                    button.center = CGPoint(x: 332 , y:275 )
                    b0=0; b1=0; b2=0; b3=0; b4=0
                    }
                
                let alert = UIAlertController(title: "Congratulations !!", message: "Do you want to play again?", preferredStyle: .alert )
                alert.addAction(UIAlertAction(title: "Restart", style: .default, handler: somehandler))
                self.present(alert, animated: true)
                //print("congrats !!")
            }
    }
    @IBAction func buttonReleased1() {
        if(distanceBetweenPoint(point1: button1.center, point2: CGPoint( x:206 , y: 539)) < 40){
            button1.center = CGPoint( x:206 , y: 539)
            b1=1
            //print("button1=",b1)
        }
        else{
            let startingPoint = button1.center
            let endpoint = CGPoint(x: 123.5 , y:374 )
            let animationDuration = 2.0
            
            let positionAnimation = constructPositionAnimation(startingPoint: startingPoint, endpoint: endpoint, animationDuration: animationDuration)
            button1.layer.add(positionAnimation    , forKey: "position")
            button1.layer.position = endpoint
            //button1.center = originalPosition
            b1=0
            //print("button1=",b1)
        }
            if(b0 == 1 && b1 == 1 && b2 == 1 && b3 == 1 && b4 == 1 ) {
                func somehandler(alert: UIAlertAction){
                    button4.center = CGPoint(x: 123.66 , y:294 )
                    button3.center = CGPoint(x: 329 , y:374 )
                    button2.center = CGPoint(x: 229.5 , y:298.5 )
                    button1.center = CGPoint(x: 123.5 , y:374 )
                    button.center = CGPoint(x: 332 , y:275 )
                    b0=0; b1=0; b2=0; b3=0; b4=0
                }
                let alert = UIAlertController(title: "Congratulations !!", message: "Do you want to play again?", preferredStyle: .alert )
                alert.addAction(UIAlertAction(title: "Restart", style: .default, handler: somehandler))
                self.present(alert, animated: true)
                //print("congrats !!")
            }
    }
    @IBAction func buttonReleased2() {
        if(distanceBetweenPoint(point1: button2.center, point2: CGPoint(x:208 , y:648.5)) < 40){
            button2.center = CGPoint(x:208 , y:648.5)
            b2=1
            //print("button2=",b2)
            
        }
        else{
            let startingPoint = button2.center
            let endpoint = CGPoint(x: 229.5 , y:298.5 )
            let animationDuration = 2.0
            
            let positionAnimation = constructPositionAnimation(startingPoint: startingPoint, endpoint: endpoint, animationDuration: animationDuration)
            button2.layer.add(positionAnimation    , forKey: "position")
            button2.layer.position = endpoint
            //button2.center = originalPosition
            b2=0
            //print("button2=",b2)
        }
            if(b0 == 1 && b1 == 1 && b2 == 1 && b3 == 1 && b4 == 1 ) {
                func somehandler(alert: UIAlertAction){
                    button4.center = CGPoint(x: 123.66 , y:294 )
                    button3.center = CGPoint(x: 329 , y:374 )
                    button2.center = CGPoint(x: 229.5 , y:298.5 )
                    button1.center = CGPoint(x: 123.5 , y:374 )
                    button.center = CGPoint(x: 332 , y:275 )
                    b0=0; b1=0; b2=0; b3=0; b4=0
                }
                let alert = UIAlertController(title: "Congratulations !!", message: "Do you want to play again?", preferredStyle: .alert )
                alert.addAction(UIAlertAction(title: "Restart", style: .default, handler: somehandler))
                self.present(alert, animated: true)
                //print("congrats !!")
            }
    }
    @IBAction func buttonReleased3() {
        if(distanceBetweenPoint(point1: button3.center,point2: CGPoint(x:128 , y:603.5)) < 40){
            button3.center = CGPoint(x:128 , y:603.5)
            b3=1
            //print("button3=",b3)
        }
        else{
            let startingPoint = button3.center
            let endpoint = CGPoint(x: 329 , y:374 )
            let animationDuration = 2.0
            
            let positionAnimation = constructPositionAnimation(startingPoint: startingPoint, endpoint: endpoint, animationDuration: animationDuration)
            button3.layer.add(positionAnimation    , forKey: "position")
            button3.layer.position = endpoint
            //button3.center = originalPosition
            b3=0
            //print("button3=",b3)
        }
        if(b0 == 1 && b1 == 1 && b2 == 1 && b3 == 1 && b4 == 1 ) {
            func somehandler(alert: UIAlertAction){
                button4.center = CGPoint(x: 123.66 , y:294 )
                button3.center = CGPoint(x: 329 , y:374 )
                button2.center = CGPoint(x: 229.5 , y:298.5 )
                button1.center = CGPoint(x: 123.5 , y:374 )
                button.center = CGPoint(x: 332 , y:275 )
                b0=0; b1=0; b2=0; b3=0; b4=0
            }
            let alert = UIAlertController(title: "Congratulations !!", message: "Do you want to play again?", preferredStyle: .alert )
            alert.addAction(UIAlertAction(title: "Restart", style: .default, handler: somehandler))
            self.present(alert, animated: true)
            //print("congrats !!")
        }
    }
    
    @IBAction func buttonReleased4() {
        if(distanceBetweenPoint(point1: button4.center, point2: CGPoint(x:285 , y: 631))  < 40){
            button4.center = CGPoint(x:285 , y: 631)
            b4 = 1
            //print("button4=",b4)
        }
        else{
            let startingPoint = button4.center
            let endpoint = CGPoint(x: 123.66 , y:294 )
            let animationDuration = 2.0
            
            let positionAnimation = constructPositionAnimation(startingPoint: startingPoint, endpoint: endpoint, animationDuration: animationDuration)
            button4.layer.add(positionAnimation	, forKey: "position")
            button4.layer.position = endpoint
            //button4.center = originalPosition
            b4 = 0
            
            
        }
            if(b0 == 1 && b1 == 1 && b2 == 1 && b3 == 1 && b4 == 1 ) {
                func somehandler(alert: UIAlertAction){
                    button4.center = CGPoint(x: 123.66 , y:294 )
                    button3.center = CGPoint(x: 329 , y:374 )
                    button2.center = CGPoint(x: 229.5 , y:298.5 )
                    button1.center = CGPoint(x: 123.5 , y:374 )
                    button.center = CGPoint(x: 332 , y:275 )
                    b0=0; b1=0; b2=0; b3=0; b4=0
                }
                let alert = UIAlertController(title: "Congratulations !!", message: "Do you want to play again?", preferredStyle: .alert )
                alert.addAction(UIAlertAction(title: "Restart", style: .default, handler: somehandler))
                self.present(alert, animated: true)
                //print("congrats !!")
            }
    }
   private func constructPositionAnimation(startingPoint: CGPoint, endpoint: CGPoint, animationDuration: Double) -> CABasicAnimation {
        let positionAnimation = CABasicAnimation(keyPath: "position")
        positionAnimation.fromValue = NSValue(cgPoint: startingPoint)
        positionAnimation.toValue = NSValue(cgPoint: endpoint)
        positionAnimation.duration = animationDuration
        positionAnimation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        return positionAnimation
    }

    private func distanceBetweenPoint(point1:CGPoint, point2:CGPoint) ->CGFloat {
        let dx: CGFloat = point2.x - point1.x
        let dy: CGFloat = point2.y - point1.y
        //let dz: CGFloat = image1.center
        return sqrt(dx*dx+dy*dy)
    }
   
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let image = UIImage(named: "GameBackground.png")
        let background = UIColor.init(patternImage: image!)
        self.view.backgroundColor = background
    }


}

